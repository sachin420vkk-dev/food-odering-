/*
 * Hotel Food Ordering System in C
 * Features: menu display, order placement, bill generation, order history.
 * Compile: gcc hotel_food_ordering.c -o hotel_food_ordering
 * Run:     ./hotel_food_ordering       (Linux/macOS)
 *          hotel_food_ordering.exe    (Windows)
 *
 * This is a recreated sample project, not the recovered original source file.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MENU_COUNT 8
#define MAX_ITEMS 100
#define MAX_ORDERS 100

typedef struct {
    int id;
    char name[40];
    float price;
} MenuItem;

typedef struct {
    int itemId;
    char itemName[40];
    int quantity;
    float unitPrice;
} OrderItem;

typedef struct {
    int orderId;
    char customerName[60];
    int tableNumber;
    int itemCount;
    OrderItem items[MAX_ITEMS];
    float subtotal;
    float tax;
    float total;
} Order;

static MenuItem menu[MENU_COUNT] = {
    {1, "Veg Burger", 80.00f},
    {2, "Cheese Pizza", 180.00f},
    {3, "Masala Dosa", 100.00f},
    {4, "Paneer Butter Masala", 220.00f},
    {5, "Veg Biryani", 160.00f},
    {6, "French Fries", 90.00f},
    {7, "Cold Coffee", 70.00f},
    {8, "Fresh Lime Soda", 50.00f}
};

static Order orders[MAX_ORDERS];
static int orderCount = 0;
static int nextOrderId = 1001;

static void clearInput(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

static int readInt(const char *prompt, int min, int max) {
    int value;
    for (;;) {
        printf("%s", prompt);
        if (scanf("%d", &value) == 1) {
            clearInput();
            if (value >= min && value <= max) return value;
        } else {
            clearInput();
        }
        printf("Invalid input. Enter a number from %d to %d.\n", min, max);
    }
}

static void readLine(const char *prompt, char *buffer, size_t size) {
    printf("%s", prompt);
    if (fgets(buffer, (int)size, stdin)) {
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') buffer[len - 1] = '\0';
        else clearInput();
    } else {
        buffer[0] = '\0';
    }
}

static void showMenu(void) {
    int i;
    printf("\n================ HOTEL FOOD MENU ================\n");
    printf("%-5s %-28s %10s\n", "ID", "Food Item", "Price (Rs.)");
    printf("-------------------------------------------------\n");
    for (i = 0; i < MENU_COUNT; i++)
        printf("%-5d %-28s %10.2f\n", menu[i].id, menu[i].name, menu[i].price);
    printf("=================================================\n");
}

static int menuIndexById(int id) {
    int i;
    for (i = 0; i < MENU_COUNT; i++)
        if (menu[i].id == id) return i;
    return -1;
}

static void printBill(const Order *o) {
    int i;
    printf("\n\n====================== CUSTOMER BILL ======================\n");
    printf("Order ID: %d\nCustomer: %s\nTable No.: %d\n",
           o->orderId, o->customerName, o->tableNumber);
    printf("-----------------------------------------------------------\n");
    printf("%-24s %8s %8s %12s\n", "Item", "Qty", "Rate", "Amount");
    printf("-----------------------------------------------------------\n");
    for (i = 0; i < o->itemCount; i++) {
        float amount = o->items[i].quantity * o->items[i].unitPrice;
        printf("%-24s %8d %8.2f %12.2f\n",
               o->items[i].itemName, o->items[i].quantity,
               o->items[i].unitPrice, amount);
    }
    printf("-----------------------------------------------------------\n");
    printf("%-42s Rs. %10.2f\n", "Subtotal:", o->subtotal);
    printf("%-42s Rs. %10.2f\n", "Tax (5%):", o->tax);
    printf("%-42s Rs. %10.2f\n", "TOTAL:", o->total);
    printf("===========================================================\n");
    printf("Thank you for visiting! Please visit again.\n");
}

static void placeOrder(void) {
    Order o;
    int choice, quantity, idx;
    if (orderCount >= MAX_ORDERS) {
        printf("Order storage is full for this session.\n");
        return;
    }

    memset(&o, 0, sizeof(o));
    o.orderId = nextOrderId++;
    readLine("Enter customer name: ", o.customerName, sizeof(o.customerName));
    if (o.customerName[0] == '\0') strcpy(o.customerName, "Guest");
    o.tableNumber = readInt("Enter table number (1-200): ", 1, 200);

    for (;;) {
        showMenu();
        printf("Current items in order: %d\n", o.itemCount);
        choice = readInt("Enter item ID to add (0 to finish): ", 0, MENU_COUNT);
        if (choice == 0) break;
        idx = menuIndexById(choice);
        if (idx < 0) {
            printf("That item ID does not exist.\n");
            continue;
        }
        quantity = readInt("Enter quantity (1-50): ", 1, 50);

        /* Combine repeated selections of the same menu item. */
        {
            int j, found = 0;
            for (j = 0; j < o.itemCount; j++) {
                if (o.items[j].itemId == choice) {
                    o.items[j].quantity += quantity;
                    found = 1;
                    break;
                }
            }
            if (!found) {
                if (o.itemCount >= MAX_ITEMS) {
                    printf("Order has reached its item limit.\n");
                    continue;
                }
                o.items[o.itemCount].itemId = menu[idx].id;
                strcpy(o.items[o.itemCount].itemName, menu[idx].name);
                o.items[o.itemCount].quantity = quantity;
                o.items[o.itemCount].unitPrice = menu[idx].price;
                o.itemCount++;
            }
        }
        printf("Added %d x %s.\n", quantity, menu[idx].name);
    }

    if (o.itemCount == 0) {
        printf("No items selected. Order cancelled.\n");
        return;
    }

    {
        int i;
        for (i = 0; i < o.itemCount; i++)
            o.subtotal += o.items[i].quantity * o.items[i].unitPrice;
    }
    o.tax = o.subtotal * 0.05f;
    o.total = o.subtotal + o.tax;
    orders[orderCount++] = o;
    printBill(&o);
    printf("Order saved in this program session.\n");
}

static void showOrderHistory(void) {
    int i;
    if (orderCount == 0) {
        printf("\nNo orders have been placed in this session.\n");
        return;
    }
    printf("\n====================== ORDER HISTORY ======================\n");
    printf("%-10s %-24s %-10s %-12s\n", "Order ID", "Customer", "Table", "Total (Rs.)");
    for (i = 0; i < orderCount; i++)
        printf("%-10d %-24.24s %-10d %-12.2f\n",
               orders[i].orderId, orders[i].customerName,
               orders[i].tableNumber, orders[i].total);
    printf("===========================================================\n");
}

int main(void) {
    int choice;
    printf("*************************************************\n");
    printf("          HOTEL FOOD ORDERING SYSTEM\n");
    printf("*************************************************\n");

    do {
        printf("\nMAIN MENU\n");
        printf("1. Display food menu\n");
        printf("2. Place a new order\n");
        printf("3. View order history\n");
        printf("4. Exit\n");
        choice = readInt("Choose an option (1-4): ", 1, 4);

        switch (choice) {
            case 1: showMenu(); break;
            case 2: placeOrder(); break;
            case 3: showOrderHistory(); break;
            case 4: printf("Exiting system. Goodbye!\n"); break;
        }
    } while (choice != 4);

    return 0;
}
