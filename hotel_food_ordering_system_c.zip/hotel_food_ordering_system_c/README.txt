HOTEL FOOD ORDERING SYSTEM IN C
================================

Files
-----
- hotel_food_ordering.c : Complete C source code
- README.txt             : Build and run instructions

Features
--------
1. Display food menu and prices
2. Enter customer name and table number
3. Add food items and quantities to an order
4. Calculate subtotal, 5% sample tax, and final total
5. Print a bill in the terminal
6. View order history during the current program session

Compile
-------
Windows (GCC / MinGW):
    gcc hotel_food_ordering.c -o hotel_food_ordering.exe
    hotel_food_ordering.exe

Linux (GCC):
    gcc hotel_food_ordering.c -o hotel_food_ordering
    ./hotel_food_ordering

Note
----
This is a recreated sample version based on the project description available in
the conversation. It is not the original file from your computer or an exact
recovery of your earlier implementation. Orders are held in memory and are lost
when the program exits.
